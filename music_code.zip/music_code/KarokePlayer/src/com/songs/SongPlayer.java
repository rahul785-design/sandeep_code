package com.songs;

import javazoom.jl.player.Player;
import java.io.FileInputStream;

public class SongPlayer {

	public static void main(String[] args) {

		String songFile = "src/song2.mp3"; // Your MP3 file name

		String[] lyrics = { "🎵 🎵 🎵 🎵..", "Srabana re srabana Megha anibu ..", "Se meghare priya ku Bhijei dabu ..",
				"Srabana re srabana Megha anibu ..", "Se meghare priya ku Bhijei dabu ..",
				"Bhijiba ku haere Se bhalapae ..", "Khusi hele premare Mate bhijae ..",
				"Se bhijile mu bhijibi Tu dhekhibu ..", "Srabana re srabana Megha anibu ..",
				"Se meghare priya ku Bhijei dabu .." };


		String[] colors = { "\u001B[31m", // Red
				"\u001B[32m", // Green
				"\u001B[33m", // Yellow
				"\u001B[34m", // Blue
				"\u001B[35m", // Magenta
				"\u001B[36m", // Cyan
				"\u001B[91m", // Bright Red
				"\u001B[92m", // Bright Green
				"\u001B[31m", // Bright Yellow
				"\u001B[94m" // Bright Blue
		};

		String RESET = "\u001B[0m";

		try {
			// Thread to play music
			Thread musicThread = new Thread(() -> {
				try {
					FileInputStream fis = new FileInputStream(songFile);
					Player player = new Player(fis);
					player.play();
				} catch (Exception e) {
					e.printStackTrace();
				}
			});

			musicThread.start(); 

			
			for (int i = 0; i < lyrics.length; i++) {
				final String line = lyrics[i];
				final String color = colors[i % colors.length]; 

				String[] words = line.split(" ");

				for (String word : words) {
					Thread wordThread = new Thread(() -> {
						System.out.print(color + word + " " + RESET);
					});
					wordThread.start();
					Thread.sleep(850); 
				}

				System.out.println(); 
				Thread.sleep(500); 
			}

			musicThread.join(); 
			System.err.println("\n🎶 Song finished!");

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
